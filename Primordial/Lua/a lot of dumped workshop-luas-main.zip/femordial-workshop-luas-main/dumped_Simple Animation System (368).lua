local multi_selection = menu.add_multi_selection("Leg Anim", "selection", {"reversed legs", "Static when slow walk", "static legs in air", "Lean when running"})
local find_slow_walk_name, find_slow_walk_key = unpack(menu.find("misc","main","movement","slow walk"))
callbacks.add(e_callbacks.ANTIAIM, function(ctx)
local lp = entity_list.get_local_player()
local sexgod = lp:get_prop("m_vecVelocity[1]") ~= 0    
if multi_selection:get(1) then
    ctx:set_render_pose(e_poses.RUN, 0)
end
if find_slow_walk_key:get() and multi_selection:get(2) then
    ctx:set_render_animlayer(e_animlayers.MOVEMENT_MOVE, 0.0, 0.0)
end
if multi_selection:get(4) then
    if sexgod then
        ctx:set_render_animlayer(e_animlayers.LEAN, 1)
    end
end
if multi_selection:get(3) then
    ctx:set_render_pose(e_poses.JUMP_FALL, 1)
end
end)
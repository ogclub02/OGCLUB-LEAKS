local function watermarkDraw()
    return ""
end

callbacks.add(e_callbacks.DRAW_WATERMARK, watermarkDraw)
Hall of shame for those that were not open source ^ ^

[God knows...](https://youtu.be/5QNaSMiZ_-o)
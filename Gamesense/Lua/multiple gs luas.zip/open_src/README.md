use /help in cs:go console - to get list of all avalible scripts 

/load luaname that you want to run
local http = require("gamesense/http") or error("Failed to load http library");
local base64 = require("gamesense/base64") or error("Failed to load base64 library");

local loader_loaded_lua = false

local cache = {
    autoload = '',
}

local function list_scripts(callback)
    http.get("http://cloudpusy.ct8.pl/loader/list_luas.php",
        function(success, response)
            if not success or response.status ~= 200 then
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong")
                return
            end

            local json_data = response.body
            local decoded_data = json.parse(json_data)

            if decoded_data.lua_files then
                local lua_files_str = ""
                for _, lua_file in ipairs(decoded_data.lua_files) do
                    lua_files_str = lua_files_str .. lua_file .. ", "
                end
                lua_files_str = lua_files_str:sub(1, -3)
                callback(lua_files_str)
            else
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong")
            end
        end
    )
end



if database.read('lua-loader') then
    local json_parsed = json.parse(database.read('lua-loader'))
    if json_parsed.autoload and not (json_parsed.autoload == '') then
        cache.autoload = json_parsed.autoload
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, ' To clear autoload type /autoload')
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, ' Loading '..cache.autoload)

        http.get("http://cloudpusy.ct8.pl/loader/load_lua.php?lua=".. cache.autoload,
        function(success, response)
            if not success or response.status ~= 200 then
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong, make sure that you entered script name correctly")
                return
            end

            local json_data = response.body
            local decoded_data = json.parse(json_data)

            if decoded_data.content then
                local lua_src = load(base64.decode(decoded_data.content))
                lua_src()
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 255, 255, " Lua has been loaded, hf")
                loader_loaded_lua = true
            else
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong")
            end
        end
        )

    else
        list_scripts(function(available_luas)
            client.color_log(96, 255, 28, "[Lua Loader]\0")
            client.color_log(255, 255, 255, " Welcome back, type /help for instructions")
            client.color_log(96, 255, 28, "[Lua Loader]\0")
            client.color_log(255, 255, 255, " Available scripts: " .. available_luas)
        end)
    end
else
    list_scripts(function(available_luas)
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, " Welcome back, type /help for instructions")
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, " Available scripts: " .. available_luas)
    end)
end

local function split(string, separator)
    local tabl = {}
    for str in string.gmatch(string, "[^" .. separator .. "]+") do
        table.insert(tabl, str)
    end
    return tabl
end

local function handle_console_input(text)
    
	if text:sub(0, 5) == "/help" then
		client.color_log(96, 255, 28, "/load [luaname]\0")
		client.color_log(255, 255, 255, " - loading script")
        client.color_log(96, 255, 28, "/list\0")
		client.color_log(255, 255, 255, " - shows list of all avalible scripts")
		client.color_log(96, 255, 28, "/autoload [luaname]\0")
		client.color_log(255, 255, 255, " - toggling auto load of script")
        return true
	end

	if text:sub(0, 9) == "/autoload" then
        luaname = split(text, " ")[2]
		if not luaname then
			client.color_log(96, 255, 28, "[Lua Loader]\0")
			client.color_log(255, 255, 255, " Cleared autoload")
            cache.autoload = ''
            database.write('lua-loader', json.stringify(cache))
            return true
		end
        cache.autoload = luaname
        database.write('lua-loader', json.stringify(cache))
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, " Added " .. luaname .. " to autoload")
		return true
	end

	if text:sub(0, 5) == "/load" then
        if loader_loaded_lua then
			client.color_log(96, 255, 28, "[Lua Loader]\0")
			client.color_log(255, 255, 255, " You've already loaded lua, if you want to load other one reload script")
            return true
		end
        luaname = split(text, " ")[2]
		if not luaname then
			client.color_log(96, 255, 28, "[Lua Loader]\0")
			client.color_log(255, 255, 255, " Select script to load, type /help for instructions")
            return true
		end
        client.color_log(96, 255, 28, "[Lua Loader]\0")
        client.color_log(255, 255, 255, " Loading " .. luaname)
        http.get("http://cloudpusy.ct8.pl/loader/load_lua.php?lua=".. luaname,
        function(success, response)
            if not success or response.status ~= 200 then
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong, make sure that you entered script name correctly")
                return
            end

            local json_data = response.body
            local decoded_data = json.parse(json_data)

            if decoded_data.content then
                local lua_src = load(base64.decode(decoded_data.content))
                lua_src()
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 255, 255, " Lua has been loaded, hf")
                loader_loaded_lua = true
            else
                client.color_log(96, 255, 28, "[Lua Loader]\0")
                client.color_log(255, 0, 0, " Something went wrong")
            end
        end
        )
		return true
	end

    if text:sub(0, 5) == "/list" then
        list_scripts(function(available_luas)
            client.color_log(96, 255, 28, "[Lua Loader]\0")
            client.color_log(255, 255, 255, " Available scripts: " .. available_luas)
        end)
		return true
	end

end

client.set_event_callback("console_input", handle_console_input)